The function of this project is to store the shooting screen of XIAO ESP32S3 Sense at a timer of 60 seconds.



This programme is compatible with esp-arduino 2.0.x as well as 3.0.x.

