The function of this project is to display the screen of XIAO ESP32S3 Sense on [Round Display for XIAO](https://www.seeedstudio.com/Seeed-Studio-Round-Display-for-XIAO-p-5638.html) in real time, there is no saving function.

This programme is compatible with esp-arduino 2.0.x as well as 3.0.x.





