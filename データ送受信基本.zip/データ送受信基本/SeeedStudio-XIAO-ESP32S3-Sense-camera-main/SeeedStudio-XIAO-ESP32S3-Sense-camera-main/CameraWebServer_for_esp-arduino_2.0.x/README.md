This project comes from [Espressif's routine CameraWebServer](https://github.com/espressif/arduino-esp32/blob/master/libraries/ESP32/examples/Camera/CameraWebServer/CameraWebServer.ino) and has been changed to work directly with XIAO ESP32S3 Sense.


Before using this routine, please check the version number of the ESP32 on-board package you are using, if it is version 3.0.x or above, please use this code:

https://github.com/limengdu/SeeedStudio-XIAO-ESP32S3-Sense-camera/blob/main/CameraWebServer_for_esp-arduino_3.0.x/CameraWebServer_for_esp-arduino_3.0.x.ino

This code only supports esp-arduino 2.0.x or above.









